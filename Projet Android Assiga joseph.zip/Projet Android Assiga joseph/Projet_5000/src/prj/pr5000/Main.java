package prj.pr5000;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class Main extends Activity  
{

   
     EditText text, text2;
     Button bt1, bt2,bt3;
     public Integer nbjoueur = 0;
     public int i;
     public int nbjoueur2;
     RadioButton rd1,rd2,rd3;
     int strategiesel,k = 0 ;
     Joueur[] joueur = new Joueur[5];
     String nom;
     private static final int CODE_MON_ACTIVITE = 1;
    

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.main);
        text  = (EditText)findViewById(R.id.montext1);
        text2 = (EditText)findViewById(R.id.montext2);
         bt1  = (Button)findViewById(R.id.monBouton);
         bt2  = (Button)findViewById(R.id.monBouton1);
         bt3  = (Button)findViewById(R.id.monBouton2);
         rd1  = (RadioButton)findViewById(R.id.RadioButton01);
         rd2  = (RadioButton)findViewById(R.id.RadioButton02);
         rd3  = (RadioButton)findViewById(R.id.RadioButton03);
        
        
        //Je recupère le nombre entré.
          bt3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
              
                try {
                   nbjoueur = Integer.valueOf(text.getText().toString().trim()) ;
                   nbjoueur2 =  nbjoueur;
                   text.setVisibility(View.INVISIBLE);
                   bt3.setVisibility(View.INVISIBLE);
                   bt3.setEnabled(false);
               
                } catch (Exception e) {
                    Toast.makeText(Main.this, "Entrez une valeur numérique avant de continuer", Toast.LENGTH_SHORT).show();
                }
                
               
            }
        });

                   
             bt1.setOnClickListener(new OnClickListener() {

                    @Override
                    public void onClick(View view) {
                           
                      if(bt3.isEnabled() == false)
                      { 
                               
                            nom = text2.getText().toString(); 
                             if(nom.isEmpty())
                             {
                             
                               Toast.makeText(Main.this, "Donner un Nom au joueur svp", Toast.LENGTH_SHORT).show();
                             
                             }
                             else
                             {
                             
                             if(rd1.isChecked())
                            {
                                   strategiesel = 1;
                                
                            
                            }else if(rd2.isChecked())
                            {
                            
                                   strategiesel = 2;
                                
                            
                            }else if(rd3.isChecked())
                            {
                            
                                   strategiesel = 3;
                            
                            }

                            joueur[k] =  new Joueur(nom, 0, strategiesel);
                            //joueur[k].setIntel(strategiesel);
                            k++;
                            text2.setText(" ");
                            if(nbjoueur == 1) bt1.setEnabled(false);
                            nbjoueur--;
                             
                             
                             }
                            

                        }
                        
                    }
                        
                  });
              
                   
        bt2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {

           if(bt1.isEnabled() == false)
           {
             Intent intent = new Intent(Main.this, activite_1.class);
             // objet qui vas nous permettre de passe des variables ici la variable passInfo
          

             Bundle objetbunble = new Bundle();
             objetbunble.putString("nbjoueur",String.valueOf(nbjoueur2 ));
             switch(nbjoueur2)
             {
                 case 1:
                     objetbunble.putString("j0", joueur[0].getNom());
                     break;

                 case 2:
                      objetbunble.putString("j0", joueur[0].getNom());
                      objetbunble.putString("j1", joueur[1].getNom());
                      objetbunble.putInt("s0", joueur[0].getIntel());
                      objetbunble.putInt("s1", joueur[1].getIntel());
                        break;
                 case 3:
                      objetbunble.putString("j0", joueur[0].getNom());
                      objetbunble.putString("j1", joueur[1].getNom());
                      objetbunble.putString("j2", joueur[2].getNom());
                      objetbunble.putInt("s0", joueur[0].getIntel());
                      objetbunble.putInt("s1", joueur[1].getIntel());
                      objetbunble.putInt("s2", joueur[2].getIntel());


                      break;

                 case 4:
                     objetbunble.putString("j0", joueur[0].getNom());
                     objetbunble.putString("j1", joueur[1].getNom());
                     objetbunble.putString("j2", joueur[2].getNom());
                     objetbunble.putString("j3", joueur[3].getNom());
                     objetbunble.putInt("s0", joueur[0].getIntel());
                     objetbunble.putInt("s1", joueur[1].getIntel());
                     objetbunble.putInt("s2", joueur[2].getIntel());
                     objetbunble.putInt("s3", joueur[3].getIntel());
                     break;

                 default :
                     objetbunble.putString("j0", joueur[0].getNom());
                     objetbunble.putString("j1", joueur[1].getNom());
                     objetbunble.putString("j2", joueur[2].getNom());
                     objetbunble.putString("j3", joueur[3].getNom());
                     objetbunble.putString("j4", joueur[4].getNom());
                     objetbunble.putInt("s0", joueur[0].getIntel());
                     objetbunble.putInt("s1", joueur[1].getIntel());
                     objetbunble.putInt("s2", joueur[2].getIntel());
                     objetbunble.putInt("s3", joueur[3].getIntel());
                     objetbunble.putInt("s4", joueur[4].getIntel());
                     break;

             }
             

              // on passe notre objet a notre activities
             intent.putExtras(objetbunble);
             startActivityForResult(intent, CODE_MON_ACTIVITE);
            
           }
            }
        });

    }
    
    @Override
    protected  void  onActivityResult(int requestCode, int reslutCode, Intent data)
    {
       text.setText("");
       text2.setText("");
       text.getHint();
       text.setVisibility(View.VISIBLE);
       bt3.setEnabled(true);
       bt3.setVisibility(View.VISIBLE);
       bt1.setEnabled(true);
       nbjoueur = 0;
       k = 0;
       return;
    
    }
    
}




    
 

