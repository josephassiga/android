/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package prj.pr5000;

/**
 *
 * @author hp
 */
public class Joueur {

    String nom;
    int points;
    int intel;

    
    public int getPoints() {
        return points;
    }

    
    
    public void setPoints(int points) {
        this.points = points;
    }

    public Joueur(String nom, int points, int intel) {
        this.nom = nom;
        this.points = points;
        this.intel = intel;
    }

    public Joueur() {
        this.nom = "inconnue";
        this.points = 0;
        this.intel = 0;
        
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getIntel() {
        return intel;
    }

    public void setIntel(int intel) {
        this.intel = intel;
    }
    

    @Override
    public String toString() {
        return "Joueur{" + "nom=" + nom + ", points=" + points + ", intel=" + intel + '}';
    }
    
    

}
