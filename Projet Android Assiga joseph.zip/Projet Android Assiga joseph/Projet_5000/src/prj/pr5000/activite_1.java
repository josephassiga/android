/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package prj.pr5000;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

/**
 *
 * @author assiga
 */
public class activite_1 extends Activity{
    Button bt1, bt2;
    EditText text;
    GridView grid, grid2;
    TextView text2;
    TableAdapter table;
    DeAdapter de;
    Intent thisIntent;
    public final int Finjeu = 5000;
    Integer[] TabDe = new Integer[5];
    private Drawable imgde;
    int nbjoueur;
    Integer[] joueurPoints = new Integer[5];
    //Joueur[] joueur = new Joueur[5];
    int seljoueur = 0;
    Integer[] valde = new Integer[5];
    int val1 = 0;
    String[] stra  = new String[5];
    String[] nom = new String[5];
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);
        bt1 = (Button)findViewById(R.id.bouton1);
        bt2 = (Button)findViewById(R.id.bouton2);
        grid  = (GridView)findViewById(R.id.mongrid);
        grid2 = (GridView)findViewById(R.id.mongrid2);
        text = (EditText)findViewById(R.id.montext2);
        table = new TableAdapter(this);        
        //On récupère l’Intent que l’on a reçu
        thisIntent = getIntent();
        nbjoueur = Integer.valueOf(thisIntent.getExtras().getString("nbjoueur"));
        de = new DeAdapter(this);
        grid.setAdapter(table);
        grid2.setAdapter(de);
        RemplirTable();
        RemplirPoint();
        //Block d'initailisation de nos Des avec des 1.
        InitDe();
        
        bt1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                
                
                  setResult(1);
                  finish(); 
                 

            }
        });
        
        
        bt2.setOnClickListener(new OnClickListener() {

            
            @Override
            public void onClick(View view) {
                 int  ptjoueur = 0;
                 RemplirTabDe();              
                 RemplirDe();  
                  //Je sélectionne un joeur pour commencer
                    seljoueur = (int)(Math.random() * nbjoueur) + 1;
                    ptjoueur = PointsJoueur();
                   
                   if(ptjoueur > 0 )
                   {
                       switch(seljoueur)
                       {
                            case 1:
                               RemplirPointsJoueur(seljoueur,  ptjoueur);
                               break;

                            case 2:
                               RemplirPointsJoueur(seljoueur,  ptjoueur);
                               break;

                            case 3:
                               RemplirPointsJoueur(seljoueur,  ptjoueur);
                               break;

                            case 4:
                               RemplirPointsJoueur(seljoueur,  ptjoueur);
                               break;

                            default:
                               RemplirPointsJoueur(seljoueur,  ptjoueur);
                               break;

                       }
                   }
                   
                    // Toast.makeText(activite_1.this, "valeur brelan: " +valbrelan, Toast.LENGTH_SHORT).show();
                

               
            }
            
            
        });
        
        

    }


    public void RemplirTable()
    {

        //On récupère les deux extra grâce à leurs id
         int val = 0;

         for (int i = 0; i < nbjoueur ; i++) nom[i] = thisIntent.getExtras().getString("j"+ i);
         for (int i = 0; i < nbjoueur ; i++)
         {
            val = thisIntent.getExtras().getInt("s"+ i);
            switch(val)
            {
                case 1 :
                 
                    stra[i] = "Joueuse";
                    break;
                    
                case 2 :
                    stra[i] = "Prudent";
                    break;
 
                case 3 :
                    stra[i] = "Experimente";
                    break;

            }

         }
 
        for (int i = 1, j = 0; i <= table.TextTab.length ; i = i + 4,j++)
         {
         
                   table.TextTab[i].setText(nom[j]);
                   table.TextTab[i + 1].setText(stra[j]);
                   table.TextTab[i - 1].setText(String.valueOf(j + 1));
               
         }
        
        NoicirTable(nbjoueur);

    }


    public void RemplirDe()
    {
          de.TextTab[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.de+TabDe[0]));
          de.TextTab[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.de+TabDe[1]));
          de.TextTab[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.de+TabDe[2]));
          de.TextTab[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.de+TabDe[3]));
          de.TextTab[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.de+TabDe[4]));

    }

    public void RemplirTabDe()
    {
        int  lower = 1;
        int higher = 6;
        
        for (int i = 0; i < TabDe.length; i++) 
        {
              TabDe[i] = (int)(Math.random()* (higher - lower)) + lower;   
        }
    
    }
   
    
    
        public void InitDe()
        {
        
             de.TextTab[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.de1));
             de.TextTab[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.de1));
             de.TextTab[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.de1));
             de.TextTab[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.de1));
             de.TextTab[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.de1));
             
        }

        
        public int BrelanDe(){
          int k = 0;
          int val = 0;
            for (int i = 0; i < TabDe.length; i++) {
                
                for (int j = 0; j < TabDe.length; j++) {
                    
                   if( TabDe[i] == TabDe[j]) 
                       valde[i]= ++k;
                    
                }
                k = 0;
            }
            
            for (int i = 0; i < valde.length; i++) 
            {
                
                if(valde[i] == 3)
                {
                   
                       switch(TabDe[i])  
                       {
                           case 1:
                               return 1000;
                               
                           case 5:
                               return  500;
                               
                           default:
                             return i * 100;

                       }        
                  
                }
            }
             
            return 0;
        
        }
        
        public int QuatreDe(){
          int k = 0;
          int val = 0;
            for (int i = 0; i < TabDe.length; i++) {
                
                for (int j = 0; j < TabDe.length; j++) {
                    
                   if( TabDe[i] == TabDe[j]) 
                       valde[i]= ++k;
                    
                }
                k = 0;
            }
            
            for (int i = 0; i < valde.length; i++) 
            {
                
                if(valde[i] == 4)
                {
                   
                       switch(TabDe[i])  
                       {
                           case 1:
                               return 2 * 1000;
                               
                           case 5:
                               return  2 * 500;
                               
                           default:
                             return 2 * (i * 100);

                       }        
                  
                }
            }
             
            return 0;
        
        }
        
        public int CinqDe(){
          int k = 0;
          int val = 0;
            for (int i = 0; i < TabDe.length; i++) {
                
                for (int j = 0; j < TabDe.length; j++) {
                    
                   if( TabDe[i] == TabDe[j]) 
                       valde[i]= ++k;
                    
                }
                k = 0;
            }
            
            for (int i = 0; i < valde.length; i++) 
            {
                
                if(valde[i] == 5)
                {
                   
                       switch(TabDe[i])  
                       {
                           case 1:
                               return 2 * 1000;
                               
                           case 5:
                               return  2 * 500;
                               
                           default:
                             return 2 * (i * 100);

                       }        
                  
                }
            }
             
            return 0;
        
        }
        
        public int FullDe(){
          int k = 0;
          int val = 0;
          int val2 = 0;
            for (int i = 0; i < TabDe.length; i++) {
                
                for (int j = 0; j < TabDe.length; j++) {
                    
                   if( TabDe[i] == TabDe[j]) 
                       valde[i]= ++k;
                    
                }
                k = 0;
            }
            
            for (int i = 0; i < valde.length; i++) 
            {
                
                if(valde[i] == 3)
                {
                   
                       switch(TabDe[i])  
                       {
                           case 1:
                               val= 1000;
                               break;
                               
                           case 5:
                               val=  500;
                               break;
                               
                           default:
                               val = i * 100;
                               break;

                       }        
                  break;// sortie du for
                }
            }
            
             for (int i = 0; i < valde.length; i++) 
            {
                
                if(valde[i] == 2)
                {
                   
                       switch(TabDe[i])  
                       {
                           case 1:
                               val2= 1*50;
                               break;
                               
                           case 5:
                               val2=  5*50;
                               break;
                               
                           default:
                               val2 = i * 100;
                               break;

                       }        
                  break;// sortie du for
                }
            }
             
             
            return  (val1 + val);
        
        }
        
         public int SuiteDe(){
             
           int val = 0;
          if((TabDe[0] == 1)  && (TabDe[1] == 2) && (TabDe[2] == 3) && (TabDe[3] == 4)&& (TabDe[4] == 5))
          {
          
               val = 1500;
          
          }
          if((TabDe[0] == 2)  && (TabDe[1] == 3) && (TabDe[2] == 4) && (TabDe[3] == 5)&& (TabDe[4] == 6))
          {
          
             val = 1500;
          
          }
          
          
            return val;
        
        }
         
         public boolean  Prudente(int pointjoueur)
         {
           boolean pt = false;
            
           if(pointjoueur > 400)
                         return true;
           
           return pt;
         
         }
         
         
         public boolean  Joueuse(int pointjoueur, int tour)
         {
           boolean pt = false;
           
            
           if(pointjoueur < 400)
           {
                 pt = false;
              
           
           }
           else if(tour == 1 )
           {
           
                tour++;
                pt = false;
           
           }
           else
           {
                tour++;
                pt = true;
           
           
           }
           
           return pt;
         
         }
        
         public boolean  Experimente(int pointjoueur)
         {
           boolean pt = false;
            
           if(pointjoueur > 400)
                         return true;
           
           return pt;
         
         }
         
         
         
        public void RemplirPointsJoueur(int numjoueur,  int valjoeur)
        {

            int v1 = 0, v2 = 0, v3 = 0, v4 = 0, v5 = 0;
           switch(nbjoueur)
            {
                case 1 :
                     v1 = Integer.valueOf(table.TextTab[3].getText().toString());
                     break;
                case 2 :
                      v1 = Integer.valueOf(table.TextTab[3].getText().toString());
                      v2 = Integer.valueOf(table.TextTab[7].getText().toString());
                     break;
                case 3 :
                    v1 = Integer.valueOf(table.TextTab[3].getText().toString());
                    v2 = Integer.valueOf(table.TextTab[7].getText().toString());
                    v3 = Integer.valueOf(table.TextTab[11].getText().toString());
                     break;
                 case 4 :
                      v1 = Integer.valueOf(table.TextTab[3].getText().toString());
                      v2 = Integer.valueOf(table.TextTab[7].getText().toString());
                      v3 = Integer.valueOf(table.TextTab[11].getText().toString());
                      v4 = Integer.valueOf(table.TextTab[15].getText().toString());
                     break;
                 default:
                      
                       v1 = Integer.valueOf(table.TextTab[3].getText().toString());
                       v2 = Integer.valueOf(table.TextTab[7].getText().toString());
                       v3 = Integer.valueOf(table.TextTab[11].getText().toString());
                       v4 = Integer.valueOf(table.TextTab[15].getText().toString());
                       v5 = Integer.valueOf(table.TextTab[19].getText().toString());
                     break;
            }
           
           switch(numjoueur)
           {
           
               case 1:
                   
                     v1 = v1 + valjoeur;
                     table.TextTab[numjoueur + 2].setText(String.valueOf(v1));
                     break;
                   
               case 2:
                    v2 = v2 + valjoeur;
                     table.TextTab[numjoueur + 5].setText(String.valueOf(v2));
                     break;
                   
               case 3:
                    v3 = v3 + valjoeur;
                    table.TextTab[numjoueur + 8].setText(String.valueOf(v3));
                     break;
                   
               case 4:
                    v4 = v4 + valjoeur;
                    table.TextTab[numjoueur + 11].setText(String.valueOf(v4));
                     break;
                  
              default:
                   v5 = v5 + valjoeur;
                     table.TextTab[numjoueur + 14].setText(String.valueOf(v5));
                     break;
          
           
           }
        
        
        
        }
        public void RemplirPoint()
        {
        
            switch(nbjoueur)
            {
                case 1 :
                     table.TextTab[3].setText(String.valueOf(0));
                     break;
                case 2 :
                     table.TextTab[3].setText(String.valueOf(0));
                     table.TextTab[7].setText(String.valueOf(0));
                     break;
                case 3 :
                     table.TextTab[3].setText(String.valueOf(0));
                     table.TextTab[7].setText(String.valueOf(0));
                     table.TextTab[11].setText(String.valueOf(0));
                     break;
                 case 4 :
                     table.TextTab[3].setText(String.valueOf(0));
                     table.TextTab[7].setText(String.valueOf(0));
                     table.TextTab[11].setText(String.valueOf(0));
                     table.TextTab[15].setText(String.valueOf(0));
                     break;
                 default:
                      table.TextTab[3].setText(String.valueOf(0));
                      table.TextTab[7].setText(String.valueOf(0));
                      table.TextTab[11].setText(String.valueOf(0));
                      table.TextTab[15].setText(String.valueOf(0));
                      table.TextTab[19].setText(String.valueOf(0));
                     break;
            }
          
        
        
        
        }
 
        
        public void NoicirTable(int numjoueur)
        {
        
            int cpt = 0;
            switch(numjoueur)
            {
                case 1:
                    cpt = 4;
                    break;
                
                case 2:
                
                    cpt = 8;
                    break;
                    
                case 3:
                    cpt = 12;
                    break;
                 
                case 4:
                    cpt = 16;
                    break;
            
            } 

            for (int i = cpt; i < table.TextTab.length; i++) {
                
                table.TextTab[i].setBackgroundColor(Color.rgb(00, 00, 00));
                
            }
        
        
        }

        
        public int PointsJoueur()
        {
            int points = 0;
            if((points = BrelanDe()) != 0)
            {
              return points;
            
            }
            else if((points = SuiteDe()) != 0)
            {
               return points;
            
            }
            else if( (points = CinqDe()) != 0)
            {
            
                return points;
            
            }
            else if((points = FullDe()) != 0)
            {
               return points;
            
            }
            else if((points = QuatreDe()) != 0)
            {
            
                 return points;
            
            }
        
        return points;
        
        }

}
