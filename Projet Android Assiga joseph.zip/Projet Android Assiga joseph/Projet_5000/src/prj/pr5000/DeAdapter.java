/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package prj.pr5000;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;

/**
 *
 * @author assiga
 */
public class DeAdapter extends BaseAdapter {
     private Context mContext;
     public  TextView[] TextTab;

    public DeAdapter(Context c) {

      mContext = c;
      TextTab = new TextView[5];
      for (int i = 0; i< TextTab.length;i++)
      {
        TextTab[i] = new TextView(mContext);
        TextTab[i].setBackgroundColor(Color.rgb(255,255,255));
        TextTab[i].setLayoutParams(new GridView.LayoutParams(50, 50));
        TextTab[i].setGravity(Gravity.CENTER);
        TextTab[i].setTextColor(Color.BLACK);
        TextTab[i].setTextAppearance(this.mContext,R.style.Bold);
      }
    }





    @Override
    public int getCount() {
        return TextTab.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
     public View getView(int position, View view, ViewGroup vg) {
        return TextTab[position];
    }

}
