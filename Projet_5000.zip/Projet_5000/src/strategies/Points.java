/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package strategies;

/**
 *
 * @author Assiga joseph
 */
public class Points {

    int point;

     public int cinq(Joueur joueur, De de) {
        int cpt=0;


        for(int i=0; i<4;i++)
        {
            if(de.de[i]==de.de[i+1])
            {
                cpt++;
            }
            if(cpt==5)
                point = 2 * brelan(joueur, de);
        }
         
         return point;
     }

      public int quatre(Joueur joueur, De de) {
        int cpt=0;


        for(int i=0; i<4;i++)
        {
            if(de.de[i]==de.de[i+1])
            {
                cpt++;
            }
            if(cpt==4)
                point = 2 * brelan(joueur, de);
        }

         return point;
     }


     public int suite(Joueur joueur, De de) {

         int point=0;
         int cpt1=0;
         int cpt2=0;
         int cpt3=0;
         int cpt4=0;
         int cpt5=0;
         int cpt6=0;

          for(int i=0; i<4;i++)
        {
            if (de.de[i]==1)
                cpt1++;
            if (de.de[i]==2)
                cpt2++;
            if (de.de[i]==3)
                cpt3++;
            if (de.de[i]==4)
                cpt4++;
            if (de.de[i]==5)
                cpt5++;
            if (de.de[i]==6)
                cpt6++;
        }
        if (cpt1==1 && cpt2==1 && cpt3==1 && cpt4==1 && cpt5==1)
            point=1500;
         else if(cpt2 == 1 && cpt3 == 1 && cpt4 == 1 && cpt5 == 1 && cpt6 == 1)
            point=1500;

         return point;
     }


     public int full(Joueur joueur, De de) {

         int point=0;
         int cpt=0;
         int cpt2=0;

         for (int i=0;i<4;i++) {
             if(de.de[0]==de.de[i+1])
                 cpt++;
         if (cpt==3)
         {
             for (int j=i;i<4;j++) {
                 if(de.de[j]==de.de[j+1] && de.de[i]!=de.de[j])
                     cpt2++;
                 if(cpt2==0)
                 {
                     
                 }
             }
         }
         }

         

         return point;
     }


     public int brelan(Joueur joueur, De de) {

         int point=0;
         int cpt=0;
         for (int i=0;i<5;i++) {
             for(int j=i+1;j<5;j++) {
                if (de.de[i]==de.de[j])
                    cpt++;
             }
             if (cpt >= 2 && de.de[i]!=1)
                return point=de.de[i]*100;
             else if(cpt == 2 && de.de[i] == 1)
                return point=1000;

         }

         return point;
     }

     public int un_cinq(Joueur joueur, De de) {

         int point=0;
         for (int i=0;i<5;i++) {
             if (de.de[i]==1)
                 point=point+100;
             if (de.de[i]==5)
                 point=point+50;
         }


         return point;
     }







     
}
