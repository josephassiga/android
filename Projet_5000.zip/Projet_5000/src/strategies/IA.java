/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package strategies;



/**
 *
 * @author Assiga joseph
 */
public class IA {


        public int prudent(Joueur player, int point, int ouverture){

            if (ouverture == 1)
            {
                if (point<400)
                {
                    //jouer(Joueur player);
                }
                else
                {
                    player.points+=point;
                    //stop
                }
            }
            else
            {
                if (player.points==5000)
                {
                    //Victoire(player);
                }
                else if(player.points > 5000)
                {
                    //jouer(Joueur player+1);
                }
                else
                {

                }
            }

           return point;
        }


    public void joueuse(Joueur player, int point, int ouverture, int coups) {
        int i = coups % 2;

        if(player.points > 5000)
                {
                    //jouer(Joueur player+1);
                }
        else { if (coups < 2)
        {
            // jouer(Joueur player);
        }
            
        }
    }

    public void experimente() {

        

    }


}
