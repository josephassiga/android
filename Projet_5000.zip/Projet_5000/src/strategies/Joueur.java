/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package strategies;

/**
 *
 * @author hp
 */
public class Joueur {

    String nom;
    int points;
    IA intel;

    public IA getIntel() {
        return intel;
    }

    
    public int getPoints() {
        return points;
    }

    public void setIntel(IA intel) {
        this.intel = intel;
    }

    
    public void setPoints(int points) {
        this.points = points;
    }

    public Joueur(String nom, int points, IA intel) {
        this.nom = nom;
        this.points = points;
        this.intel = intel;
    }

    public Joueur() {
        this.nom = "";
        this.points = 0;
        this.intel = null;
        
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
    

    @Override
    public String toString() {
        return "Joueur{" + "nom=" + nom + ", points=" + points + ", intel=" + intel + '}';
    }
    
    

}
