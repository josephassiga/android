/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package strategies;

/**
 *
 * @author Assiga joseph
 */
public class De {

    int de[];
    int locke[];
    int cptlock;

}
