package prj.pr5000;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import strategies.IA;
import strategies.Joueur;

public class Main extends Activity  
{

   
     EditText text, text2;
     Button bt1, bt2,bt3;
     public int nbjoueur,i;
     private Context lecontext;
     Joueur joueur;
     RadioButton rd1,rd2,rd3;
     IA st ;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        text  = (EditText)findViewById(R.id.montext1);
        text2 = (EditText)findViewById(R.id.montext2);
         bt1  = (Button)findViewById(R.id.monBouton);
         bt2  = (Button)findViewById(R.id.monBouton1);
         bt3  = (Button)findViewById(R.id.monBouton2);
         rd1  = (RadioButton)findViewById(R.id.RadioButton01);
         rd2  = (RadioButton)findViewById(R.id.RadioButton02);
         rd3  = (RadioButton)findViewById(R.id.RadioButton03);
        
        
        //Je recupère le nombre entré.
          bt3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
               nbjoueur = Integer.parseInt(text.getText().toString());
               //Toast.makeText(Main.this, "valeur sélectionné: "+val, Toast.LENGTH_LONG).show();
               text.setVisibility(View.INVISIBLE);
               bt3.setVisibility(View.INVISIBLE);            
            }
        });

                   
                       bt1.setOnClickListener(new OnClickListener() {

                        @Override
                        public void onClick(View view) {
                             // Toast.makeText(Main.this, "valeur joué: " +nbjoueur, Toast.LENGTH_LONG).show();
                             //je crèe mes joeurs avec leur caractéristiques:
                             //je recupère le nom du joueur
                            String nom = text2.getText().toString();
                            
                            
                            if(rd1.isChecked())
                            {
                                  st.joueuse(joueur, i, nbjoueur, i);
                                
                            
                            }else if(rd2.isChecked())
                            {
                            
                                  st.prudent(joueur, 0, 1);
                                
                            
                            }else
                            {
                            
                                  st.experimente();
                            
                            }
                            
                            joueur = new Joueur(nom, 0, st);
                            
                           text2.setText(" ");
                           if(nbjoueur == 1) bt1.setEnabled(false);  
                           nbjoueur--;
   

                        }
                        });
              
                   
        bt2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {


                Intent intent = new Intent(lecontext, activite_1.class);
             // objet qui vas nous permettre de passe des variables ici la variable passInfo
             Bundle objetbunble = new Bundle();
             objetbunble .putString("passInfo",text.getText().toString());
              // on passe notre objet a notre activities
             intent.putExtras(objetbunble );
             // on appelle notre activité
             lecontext.startActivity(intent);
            //val = Integer.parseInt(text.getText().toString());
            }
        });

  


    }
}


    
 

