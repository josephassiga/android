/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package prj.pr5000;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

/**
 *
 * @author assiga
 */
public class activite_1 extends Activity {
    Button bt;
    EditText text;
    Main main = new Main();
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);
        bt = (Button)findViewById(R.id.monBouton2);
        //bt.setOnClickListener(this);
        text = (EditText)findViewById(R.id.montext2);


    }



   

 


}
