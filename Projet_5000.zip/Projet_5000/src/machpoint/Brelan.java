/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package machpoint;

/**
 *
 * @author assiga
 */
public class Brelan {

    private int des = 0;

    public Brelan() {

        this.des = 3;
    }

    public int getDes() {
        return des;
    }

    @Override
    public String toString() {
        return "Brelan{" + "des=" + des + '}';
    }

    public void setDes(int des) {
        this.des = des;
    }




}
